<?php
header('Location/public/');
?>
