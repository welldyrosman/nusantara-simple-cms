<div class="container-fluid bg-success">
    <div class="text-center p-3">
        <img src="{{URL::asset('/i/website_img/logo-white.png')}}" alt="{{ config('settings.site_title') }}" width="" height="30" />
        <div class="d-flex">

        </div>
    </div>
</div>
<nav class="navbar navbar-expand-lg navbar-dark bg-success">
    <div class="container-fluid">
        <div class="text-light">
            Copyright@2023 <span class="text-warning">nusantaraaqiqah.com</span> All Right Reserved
        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                @foreach (getMenu() as $p)
                @if ($p->children->count() > 0)
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        {{ $p->title }}
                    </a>
                    <ul class="dropdown-menu">
                        @foreach ($p->children as $child)
                        <li><a class="dropdown-item" href="#">{{ $child->title }}</a></li>
                        @endforeach
                    </ul>
                </li>
                @else
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#"> {{ $p->title }}</a>
                </li>
                @endif
                @endforeach

            </ul>
        </div> -->
    </div>
</nav>
