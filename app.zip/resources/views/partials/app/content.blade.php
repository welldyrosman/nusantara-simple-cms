<section class="section mt-5">
    <div class="container-fluid">
        <div class="columns">
            <div class="column is-offset-2 is-8">
                <div class="box">
                    <div class="content">{!! $content !!}</div>
                </div>
                @include('partials.app.breadcrumbs')
            </div>
        </div>
    </div>
</section>
