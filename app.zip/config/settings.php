<?php

return [
    'analytics_id'     => null,
    'logo'             => 'i/website_img/logo.png',
    'login_image'      => 'https://ssl.gstatic.com/accounts/ui/avatar_2x.png',
    'site_description' => 'Mari berpartisipasi dalam ibadah kurban dan aqiqah di Nusantara Aqiqah untuk meraih pahala dan berbagi berkah. Bersama-sama, kita dapat menjalankan kewajiban agama dengan tulus dan ikhlas. Ayo, mari saling berkolaborasi dalam pengurbanan hewan qurban dan aqiqah untuk memenuhi kebutuhan masyarakat yang membutuhkan.

    Jadilah bagian dari upaya kita untuk memberikan makanan kepada yang lapar, membantu mereka yang kurang mampu, dan menguatkan ikatan persaudaraan di tengah-tengah kita. Mari tingkatkan kebaikan kita dan berbagi kebahagiaan dengan mempercayakan ibadah kurban dan aqiqah kepada Nusantara Aqiqah, yang memiliki pengalaman dan keahlian dalam mengelola ibadah ini. Dengan bergabung bersama, kita dapat mewujudkan semangat berbagi dan kepedulian kepada sesama dalam merayakan momen yang istimewa ini.',
    'site_title'       => 'Nusantara Aqiqah'
];
