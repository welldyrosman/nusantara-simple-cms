<section class="section">
    <div class="container">
        <div class="columns">
            <div class="column is-offset-2 is-8">
                <div class="box">
                    <div class="content"><?php echo $content; ?></div>
                </div>
                <?php echo $__env->make('partials.app.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/content.blade.php ENDPATH**/ ?>