<div class="card mt-5" style="width: 18rem;">
                    <div class="card-header text-bg-success f-med">
                        Artikel Terpopuler
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?php echo e(URL::asset('/i/website_img/kambing.png')); ?>" class="img-fluid rounded-start" alt="...">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body p-1 ">
                                        <p class="card-title content-article-2 f-sbold"><?php echo e($article->title); ?></p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/popular.blade.php ENDPATH**/ ?>