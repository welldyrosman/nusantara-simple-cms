<div class="row my-3">
    <div class="col">
        <div class="d-flex align-items-center">
            <h3 class="f-sbold">Artikel Terkait</h3>
            <hr class="flex-grow-1 custom-hr">
        </div>
    </div>
</div>
<section class="pt-5 pb-5 carousel-related">
    <div class="row">

        <div class="col-12">
            <div id="carouselExampleIndicators2" class="carousel slide" data-bs-ride="carousel">

                <div class="carousel-inner">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key % 3 === 0): ?>
                    <div class="carousel-item<?php echo e($key === 0 ? ' active' : ''); ?>">
                        <div class="row">
                            <?php endif; ?>

                            <div class="col-md-4 mb-3">
                                <div class="card">
                                    <img class="img-fluid" alt="100%x280" src="/i/website_img/image-4.jpg">
                                    <div class="card-body">
                                        <p class="card-title content-article-1 f-sbold"><?php echo e($article['title']); ?></p>
                                        <p class="card-text content-article-3"><?php echo e($article['content']); ?></p>
                                    </div>
                                </div>
                            </div>

                            <?php if(($key + 1) % 3 === 0 || $key === count($articles) - 1): ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators2" role="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide="prev">
                    <i class="bi bi-chevron-left"></i>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators2" role="button" data-bs-target="#carouselExampleIndicators2" data-bs-slide="next">
                    <i class="bi bi-chevron-right"></i>
                </a>
            </div>
        </div>
    </div>
</section>

<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/relatedarticle.blade.php ENDPATH**/ ?>