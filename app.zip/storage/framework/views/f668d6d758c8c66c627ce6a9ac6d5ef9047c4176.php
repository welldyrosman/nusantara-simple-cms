<nav class="breadcrumb is-small is-centered" aria-label="breadcrumbs">
    <ul>
        <li><a href="<?php echo e(route('root')); ?>"><?php echo e(getTitle()); ?></a></li>
        <?php if(isset($object->parent)): ?>
            <li><a href="<?php echo e($object->parent->link); ?>"><?php echo e($object->parent->title); ?></a></li>
        <?php elseif(isset($object->category)): ?>
            <li><a href="<?php echo e($object->category->link); ?>"><?php echo e($object->category->title); ?></a></li>
        <?php endif; ?>
        <li class="is-active"><a href="<?php echo e(url()->current()); ?>}" aria-current="page"><?php echo e($object->title); ?></a></li>
    </ul>
</nav>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/breadcrumbs.blade.php ENDPATH**/ ?>