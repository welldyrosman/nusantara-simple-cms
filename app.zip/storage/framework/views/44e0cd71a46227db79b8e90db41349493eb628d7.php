

<?php $__env->startSection('title'); ?><?php echo e(getTitle($t = __('http.404.title'))); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e(getDescription($d = __('http.404.description'))); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.app.hero', ['title' => $t, 'description' => $d, 'class' => 'is-large'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/errors/404.blade.php ENDPATH**/ ?>