<section class="content-header">
    <?php $route = Route::currentRouteName() ?>
    <?php $index = substr($route, 0, strrpos($route, '.') + 1) . 'index' ?>
    <nav class="breadcrumb is-centered" aria-label="breadcrumbs">
        <ul>
            <li><a href="<?php echo e(route('root')); ?>"><?php echo e(config('settings.site_title')); ?></a></li>
            <li><a href="<?php echo e(route('admin.dashboard.index')); ?>"><?php echo e(__('admin.dashboard.index')); ?></a></li>
            <?php if(strpos($route, 'root') === false && Route::has($index)): ?>
                <?php $isIndex = strpos($route, 'index') !== false ?>
                <?php $parent_text= __($isIndex ? $route : $index) ?>
                <li class="<?php echo e($isIndex ? 'is-active' : ''); ?>">
                    <?php if($isIndex): ?>
                        <a href="#" aria-current="page"><?php echo e(empty($t) ? $parent_text : $t); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(route($index)); ?>"><?php echo e($parent_text); ?></a>
                    <?php endif; ?>
                </li>
                <?php if(!$isIndex): ?><li class="is-active"><a href="#" aria-current="page"><?php echo e(empty($t) ? __($route) : $t); ?></a></li><?php endif; ?>
            <?php endif; ?>
        </ul>
    </nav>
</section>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/breadcrumbs.blade.php ENDPATH**/ ?>