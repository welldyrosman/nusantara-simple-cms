<section class="section">
    <div class="container">
        <h1 class="title"><?php echo e(__('admin.' . $resource . '.' . ($action ?? 'show'))); ?></h1>
        <?php [$name, $id] = ${$resource} !== null ? ['update', ${$resource}->id] : ['store', null] ?>
        <?php echo $__env->make('partials.admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/show/init.blade.php ENDPATH**/ ?>