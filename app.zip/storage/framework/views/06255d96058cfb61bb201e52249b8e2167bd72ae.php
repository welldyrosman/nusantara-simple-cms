<div class="navbar-item has-dropdown is-hoverable">
    <div class="navbar-link">
        <span class="icon"><?php echo icon($icon); ?></span>
        <span><?php echo e(empty($resource) && !empty($text) ? $text : __('admin.' . $resource . '.index')); ?></span>
    </div>
    <div class="navbar-dropdown">
        <?php if(empty($items)): ?>
            <a class="navbar-item" href="<?php echo e(route('admin.' . $resource . '.create')); ?>">
                <span class="icon"><?php echo icon('plus'); ?></span>
                <span><?php echo e(__('admin.' . $resource . '.create')); ?></span>
            </a>
            <?php if(!empty($extra)): ?>
                <?php $__currentLoopData = \Illuminate\Support\Arr::wrap($extra); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="navbar-item" href="<?php echo e(route('admin.' . $resource . '.' . $e)); ?>">
                        <span class="icon"><?php echo icon($i); ?></span>
                        <span><?php echo e(__('admin.' . $resource . '.' . $e)); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <a class="navbar-item" href="<?php echo e(route('admin.' . $resource . '.index')); ?>">
                <span class="icon"><?php echo icon('list'); ?></span>
                <span><?php echo e(__('admin.' . $resource . '.index')); ?></span>
            </a>
        <?php else: ?>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="navbar-item" href="<?php echo e($values[0]); ?>">
                    <span class="icon"><?php echo icon($values[1]); ?></span>
                    <span><?php echo e($text); ?></span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/nav/dropdown.blade.php ENDPATH**/ ?>