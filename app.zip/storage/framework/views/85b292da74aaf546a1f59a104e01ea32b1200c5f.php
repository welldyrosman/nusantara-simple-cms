<div class="field">
    <label class="label"><?php echo e(__('admin.fields.' . $resource . '.' . $attribute)); ?></label>
    <div class="control">
        <?php $value = (${$resource}->$attribute ?? old($attribute)) ?>
        <input readonly class="input is-large <?php echo e(($class ?? '')); ?>" value="<?php echo e(empty($value) ? ($default ?? '') : $value); ?>" type="<?php echo e($type ?? 'text'); ?>" name="<?php echo e($attribute); ?>">
    </div>
</div>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/show/text.blade.php ENDPATH**/ ?>