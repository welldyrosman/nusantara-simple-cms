<?php $t = __('admin.elfinder.index') ?>



<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset($dir . '/css/elfinder.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset($dir . '/css/theme.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container is-fluid">
            <div class="columns">
                <div class="column is-12">
                    <div id="elfinder"></div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset($dir.'/js/elfinder.min.js')); ?>"></script>
    <script type="text/javascript" charset="utf-8">
      $(function() {
        $('#elfinder').elfinder({
            customData: {
              _token: '<?php echo e(csrf_token()); ?>'
            },
          url : '<?php echo e(route('elfinder.connector')); ?>',  // connector URL
          soundPath: '<?php echo e(asset($dir.'/sounds')); ?>'
        });
      });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/vendor/elfinder/elfinder.blade.php ENDPATH**/ ?>