<?php $__env->startSection('title'); ?><?php echo e($title ?? getTitle()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?><?php echo e($description ?? getDescription()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?><?php echo e($image ?? getImage()); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('facebook'); ?><?php echo e(getFacebookShareLink($currentUrl ?? request()->url(), $title ?? getTitle())); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('twitter'); ?><?php echo e(getTwitterShareLink($currentUrl ?? request()->url(), $title ?? getTitle())); ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('robots'); ?><?php echo e($robots ?? getRobots()); ?><?php $__env->stopSection(); ?>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/sections.blade.php ENDPATH**/ ?>