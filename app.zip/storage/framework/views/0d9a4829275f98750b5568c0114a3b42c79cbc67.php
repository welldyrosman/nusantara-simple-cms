<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title><?php echo e(empty($t) ? (is_array($title = __(Route::getCurrentRoute()->getName())) ? $title['title'] : $title) : $t); ?> | <?php echo e(config('settings.site_title')); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset(mix('dist/css/admin.css'))); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('i/icons/favicon.ico')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
<?php if($currentUser = auth()->user()): ?><?php echo $__env->make('partials.admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
<?php if(session('message')): ?><div class="notification is-info"><?php echo e(session('message')); ?></div><?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
<?php if($currentUser = auth()->user()): ?><?php echo $__env->make('partials.admin.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
<script src="<?php echo e(asset(mix('dist/js/admin.js'))); ?>" type="text/javascript"></script>
<?php if (! empty(trim($__env->yieldContent('scripts')))): ?><?php echo $__env->yieldContent('scripts'); ?><?php endif; ?>
</body>
</html>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/layouts/admin.blade.php ENDPATH**/ ?>