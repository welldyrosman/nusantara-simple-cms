<?php echo $__env->make('partials.app.sections', [
'title' => getTitle($title),
'description' => getDescription($description),
'image' => getImage()
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="section">
    <div class="container my-5">
        <div class="row">
            <div class="col-9">
                <?php echo $__env->make('partials.app.contentarticle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('partials.app.relatedarticle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-3">
                <?php echo $__env->make('partials.app.popular', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/app/articledetail.blade.php ENDPATH**/ ?>