<a class="navbar-item" href="<?php echo e(!empty($resource) && empty($link) ? route('admin.' . $resource . '.index') : $link); ?>">
    <span class="icon"><?php echo icon($icon); ?></span>
    <span><?php echo e(!empty($resource) && empty($text) ? __('admin.' . $resource . '.index') : $text); ?></span>
</a>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/nav/single.blade.php ENDPATH**/ ?>