<div class="mt-5">
    <h2 class="f-sbold">Apa Itu Kurban?</h2>
    <div class="d-flex justify-content-between mb-3">
        <div class="d-flex">
            <div class="me-3">Penulis : Redaksi</div>
            <div>Kategori : Kurban</div>
        </div>
        <div>Jumat 9 Juni 2023</div>


    </div>
    <img src="/i/website_img/article.png" class="img img-fluid w-100 mb-3"/>
    <div class="content-article">
        NUSANTARAAQIQAH.COM - Setiap tahun selama bulan Dzul Hijjah Islam, umat Islam di seluruh dunia menyembelih hewan - kambing, domba, sapi atau unta - untuk mencerminkan kesediaan Nabi Ibrahim untuk mengorbankan putranya Ismail, demi Tuhan. Pada tahun 2023, pendistribusian Qurban ditargetkan untuk menjangkau lebih banyak orang dari sebelumnya.
        Setelah hewan disembelih, dagingnya kemudian dibagikan kepada mereka yang paling membutuhkan. Anda juga bisa mengetahui lebih jauh bagaimana Islamic Relief mendistribusikan daging Qurban melalui tanya jawab di bawah ini.
    </div>
</div>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/contentarticle.blade.php ENDPATH**/ ?>