<div class="field">
    <label class="label"><?php echo e(__('admin.fields.' . $resource . '.' . $attribute)); ?></label>
    <div class="control">
        <div class="select is-medium is-fullwidth">
            <select name="<?php echo e($attribute); ?>" disabled>
                <?php if(isset($null) && $null === true): ?>
                    <option value="<?php echo e(null); ?>"><?php echo e(__('admin.none')); ?></option>
                <?php endif; ?>
                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($key === (${$resource}->$attribute ?? old($attribute)) ? 'selected' : ''); ?> value="<?php echo e(isset($valueOnly) ? $value :  $key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/admin/show/dropdown.blade.php ENDPATH**/ ?>