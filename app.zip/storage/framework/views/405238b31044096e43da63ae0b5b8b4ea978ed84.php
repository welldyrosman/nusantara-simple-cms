<?php
use Illuminate\Support\Facades\Request;

$jsonFile = public_path('dist/json/menu.json');
$menus = json_decode(file_get_contents($jsonFile));
$currentUrl = url()->current();
?>

<nav class="navbar navbar-expand-lg fixed-top bg-white">
    <div class="container">
        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset(config('settings.logo'))); ?>" alt="<?php echo e(config('settings.site_title')); ?>" width="" height="30" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(count($p->children) > 0): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link class="nav-link <?php echo e(url($p->url)===$currentUrl ? 'active' : ''); ?>" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo e($p->title); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $p->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="#"><?php echo e($child->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php else: ?>

                <li class="nav-item">
                    <a class="nav-link <?php echo e(url($p->url)===$currentUrl ? 'active' : ''); ?>" aria-current="page" href="<?php echo e($p->url); ?>"><?php echo e($p->title); ?></a>
                </li>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Private\project\NusantaraAqiqah\nusantara-simple-cms\resources\views/partials/app/nav.blade.php ENDPATH**/ ?>